module.exports = {
  mongoURI: 'YOUR_MONGODB_CONNECTION_STRING',
  jwtSecret: 'YOUR_SECRET_KEY'
};