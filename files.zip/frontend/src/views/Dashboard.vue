<template>
  <div class="dashboard">
    <h1>Dashboard</h1>
    <router-link to="/properties">Manage Properties</router-link>
    <router-link to="/tenants">Manage Tenants</router-link>
    <router-link to="/rent">Manage Rent</router-link>
  </div>
</template>

<script>
export default {
  name: 'Dashboard',
};
</script>

<style scoped>
.dashboard {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>