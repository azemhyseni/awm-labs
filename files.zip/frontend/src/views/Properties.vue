<template>
  <div class="properties">
    <h1>Manage Properties</h1>
    <!-- Add property management functionality here -->
  </div>
</template>

<script>
export default {
  name: 'Properties',
};
</script>

<style scoped>
.properties {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>