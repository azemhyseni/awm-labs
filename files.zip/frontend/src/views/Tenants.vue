<template>
  <div class="tenants">
    <h1>Manage Tenants</h1>
    <!-- Add tenant management functionality here -->
  </div>
</template>

<script>
export default {
  name: 'Tenants',
};
</script>

<style scoped>
.tenants {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>