<template>
  <div class="home">
    <h1>Welcome to ERP Rent Management</h1>
    <router-link to="/login">Login</router-link>
  </div>
</template>

<script>
export default {
  name: 'Home',
};
</script>

<style scoped>
.home {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>