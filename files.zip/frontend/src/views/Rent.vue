<template>
  <div class="rent">
    <h1>Manage Rent</h1>
    <!-- Add rent management functionality here -->
  </div>
</template>

<script>
export default {
  name: 'Rent',
};
</script>

<style scoped>
.rent {
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>