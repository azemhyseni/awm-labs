import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue';
import Login from '../views/Login.vue';
import Dashboard from '../views/Dashboard.vue';
import Properties from '../views/Properties.vue';
import Tenants from '../views/Tenants.vue';
import Rent from '../views/Rent.vue';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
  },
  {
    path: '/login',
    name: 'Login',
    component: Login,
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: Dashboard,
  },
  {
    path: '/properties',
    name: 'Properties',
    component: Properties,
  },
  {
    path: '/tenants',
    name: 'Tenants',
    component: Tenants,
  },
  {
    path: '/rent',
    name: 'Rent',
    component: Rent,
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;