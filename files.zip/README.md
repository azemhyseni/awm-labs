# ERP Rent Management System

This is a simple ERP system for managing rent, built with Node.js and Express for the backend, and Vue.js for the frontend.

## Features

- User Authentication
- Property Management
- Tenant Management
- Rent Collection and Payment Tracking
- Reporting

## Getting Started

### Prerequisites

- Node.js
- MongoDB

### Installation

1. Clone the repository:
   ```sh
   git clone https://github.com/yourusername/erp-rent-management.git
   ```

2. Change to the project directory:
   ```sh
   cd erp-rent-management
   ```

3. Install the backend dependencies:
   ```sh
   cd backend
   npm install
   ```

4. Install the frontend dependencies:
   ```sh
   cd ../frontend
   npm install
   ```

5. Create a `.env` file in the backend directory and add your MongoDB connection string and JWT secret:
   ```env
   MONGO_URI=your_mongodb_connection_string
   JWT_SECRET=your_secret_key
   ```

6. Start the backend server:
   ```sh
   cd backend
   npm start
   ```

7. Start the frontend development server:
   ```sh
   cd ../frontend
   npm run serve
   ```

8. Open `http://localhost:8080` in your browser.

## License

This project is licensed under the MIT License.